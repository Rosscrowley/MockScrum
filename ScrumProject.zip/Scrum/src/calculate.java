
public class calculate {

	
	private int calEssential;
	private int calLuxury;
	private int calGift;
	
	
	public calculate(int calEssential, int calLuxury, int calGift) {
		
		this.calEssential = calEssential;
		this.calLuxury = calLuxury;
		this.calGift = calGift;
		
	}
	
	public int getEssential() {
		return calEssential;
	}

	public void setEssential(int calEssential) {
		this.calEssential = calEssential;
	}
	
	public int getLuxury() {
		return calLuxury;
	}

	public void setLuxury(int calLuxury) {
		this.calLuxury = calLuxury;
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}//end
