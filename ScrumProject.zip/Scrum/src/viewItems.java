
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

public class viewItems extends JFrame implements ActionListener {

	
	JButton view, exit, add;

	public viewItems() {

		
		
		exit = new JButton("EXIT");

		JMenuBar menuBar = new JMenuBar();
		
		
		menuBar.add(exit);
		

		
		
		exit.addActionListener(this);

		JPanel pnl = new JPanel();

		this.setTitle("View Items");
		this.setVisible(true);
		this.setSize(600, 400);
		pnl.setBackground(Color.YELLOW);
		this.add(pnl);
		this.setJMenuBar(menuBar);

	}
	

	@Override
	public void actionPerformed(ActionEvent e) {

		

		if (e.getSource() == exit) {

			Frame home = new Frame();
			

		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	viewItems f = new viewItems();

	}
}


