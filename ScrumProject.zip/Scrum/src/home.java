import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JMenuBar;
import javax.swing.JPanel;

public class home extends JFrame implements ActionListener {

	
	JButton view, exit, add;

	public home() {

		
		add = new JButton("ADD ITEMS");
		view = new JButton("VIEW ITEMS");
		exit = new JButton("EXIT");

		JMenuBar menuBar = new JMenuBar();
		
		menuBar.add(add);
		menuBar.add(view);
		menuBar.add(exit);
		

		
		add.addActionListener(this);
		view.addActionListener(this);
		exit.addActionListener(this);

		JPanel pnl = new JPanel();

		this.setTitle("A Web Page");
		this.setVisible(true);
		this.setSize(600, 400);
		pnl.setBackground(Color.cyan);
		this.add(pnl);
		this.setJMenuBar(menuBar);

	}

	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == add) { // when this button is pressed cutomers should be able to add something

			// this.dispose();
			adding add = new adding();

		}		

		if (e.getSource() == view) { //// when this button is pressed cutomers should be able to view the products 

			viewItems frame3 = new viewItems();

		}
		

		if (e.getSource() == exit) {

			Frame home = new Frame();

		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	home f = new home();

	}
}

